+++
title = "Contact"
id = "contact"
+++

# We are here to help you

#### **At Learn Robotics, QUALITY education is our #1 goal, but having FUN is our #1 priority!** 

<br>

Are you curious about **hosting** or **sponsoring** a Learn Robotics event? 

Please feel free to contact us via the methods below! We will do our best to respond to your inquiries within 24-hours.

<br>
<center>
<i class="fa fa-phone fa-2x" aria-hidden="true" ></i>    860-578-4459 <br>
<i class="fa fa-envelope fa-2x" aria-hidden="true" ></i>   [LearnRobotics@mail.com](mailto:learnrobotics@mail.com)
<br>
#### [Like Us on Facebook!](http://facebook.com/LearnRoboticsClass)
<br></center>



