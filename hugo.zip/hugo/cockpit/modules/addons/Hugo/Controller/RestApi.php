<?php
namespace Hugo\Controller;

class RestApi extends \LimeExtra\Controller {

    public function get($collection=null) {



        return null;
    }
}
